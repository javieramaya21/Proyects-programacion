
package Gestion_de_inventarios;

import java.util.Scanner;
 
public class MainEnvios {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("╔════════════════════════════════════╗");
        System.out.println("║    CALCULADORA DE ENVÍOS     ║");
        System.out.println("╠════════════════════════════════════╣");
        System.out.println("║  1. Estándar  ($150 por kg)  ║");
        System.out.println("║  2. Express   ($300 por kg)  ║");
        System.out.println("║  3. Mismo Día ($400 por kg)  ║");
        System.out.println("╚════════════════════════════════════╝");
        System.out.print("Selecciona el tipo de envío (1-3): ");
 
        int opcion = sc.nextInt();
 
        TipoEnvios tipo;
        switch (opcion) {
            case 1: tipo = TipoEnvios.ESTANDAR; 
            break;
            case 2: tipo = TipoEnvios.EXPRESS;   
            break;
            case 3: tipo = TipoEnvios.MISMO_DIA;  
            break;
            
            default:
                System.out.println("Opción inválida.");
                sc.close();
                return;
        }
 
        System.out.print("Ingresa el peso del paquete (kg): ");
        double peso = sc.nextDouble();
 
        try {
            double costo = tipo.calcularCosto(peso);
          
            System.out.println("Tipo de envío : " + tipo.name());
            System.out.printf ("Peso          : %.2f kg%n", peso);
            System.out.printf ("Costo total   : $%.2f%n", costo);
        } catch (PesoInvalidoException e) {
           
            System.out.println("ERROR: " + e.getMessage());
        }
 
        sc.close();
    }
}
