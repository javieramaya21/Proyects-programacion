
package Gestion_de_inventarios;

public enum TipoEnvios implements Envios {
 
    ESTANDAR {
        @Override
        public double calcularCosto(double peso) throws PesoInvalidoException {
            validarPeso(peso);
            return peso * 150;
        }
    },
 
    EXPRESS {
        @Override
        public double calcularCosto(double peso) throws PesoInvalidoException {
            validarPeso(peso);
            return peso * 300;
        }
    },
 
    MISMO_DIA {
        @Override
        public double calcularCosto(double peso) throws PesoInvalidoException {
            validarPeso(peso);
            return peso * 400;
        }
    };
 
    /** Valida que el peso esté en el rango permitido (0 < peso <= 200). */
    protected void validarPeso(double peso) throws PesoInvalidoException {
        if (peso <= 0 || peso > 200) {
            throw new PesoInvalidoException(
                "Peso fuera del rango permitido. El peso debe estar entre 0 y 200 kg. " +
                "Peso ingresado: " + peso + " kg.");
        }
    }
}
