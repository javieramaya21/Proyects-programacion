
package Gestion_de_inventarios;


import java.util.Scanner;
 
public class MainCalculadora {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("╔══════════════════════════════╗");
        System.out.println("║       CALCULADORA       ║");
        System.out.println("╠══════════════════════════════╣");
        System.out.println("║  1. SUMA                ║");
        System.out.println("║  2. RESTA               ║");
        System.out.println("║  3. MULTIPLICACION      ║");
        System.out.println("║  4. DIVISION            ║");
        System.out.println("╚══════════════════════════════╝");
        System.out.print("Selecciona una operacion (1-4): ");
 
        int opcion = sc.nextInt();
 
        Operacion op;
        switch (opcion) {
            
            case 1: op = Operacion.SUMA; 
            break;
            
            case 2: op = Operacion.RESTA;   
            break;
            
            case 3: op = Operacion.MULTIPLICACION; 
            break;
            
            case 4: op = Operacion.DIVISION;  
            break;
            
            default:
                System.out.println("Opción inválida.");
                sc.close();
                return;
        }
 
        System.out.print("Ingresa el primer número (x): ");
        int x = sc.nextInt();
        System.out.print("Ingresa el segundo número (y): ");
        int y = sc.nextInt();
 
        try {
            int resultado = op.ejecutar(x, y);
           
            System.out.println("Operación : " + op.name());
            System.out.println("Resultado : " + x + " " + simbolo(op) + " " + y + " = " + resultado);
        } catch (ArithmeticException e) {
            
            System.out.println(e.getMessage());
        }
 
        sc.close();
    }
 
    /* Devuelve el símbolo matemático de cada operación. */
    private static String simbolo(Operacion op) {
        switch (op) {
            
            case SUMA:        
                return "+";
            case RESTA:        
                return "-";
            case MULTIPLICACION: 
                return "*";
            case DIVISION:      
                return "/";
            default:        
                return "?";
        }
    }
}