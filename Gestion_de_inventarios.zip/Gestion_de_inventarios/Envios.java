
package Gestion_de_inventarios;


public interface Envios {
    
    double calcularCosto(double peso) throws PesoInvalidoException;
    
}
 
