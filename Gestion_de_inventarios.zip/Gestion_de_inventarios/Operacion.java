
package Gestion_de_inventarios;


public enum Operacion implements Calculadora {
 
    SUMA {
        @Override
        public int ejecutar(int x, int y) {
            return x + y;
        }
    },
 
    RESTA {
        @Override
        public int ejecutar(int x, int y) {
            return x - y;
        }
    },
 
    MULTIPLICACION {
        @Override
        public int ejecutar(int x, int y) {
            return x * y;
        }
    },
 
    DIVISION {
        @Override
        public int ejecutar(int x, int y) {
            if (y == 0) {
                throw new ArithmeticException("Error: No se puede dividir entre cero.");
            }
            return x / y;
        }
    };
}
