
package Gestion_de_inventarios;

public class PesoInvalidoException extends Exception {
    
    public PesoInvalidoException(String mensaje) {
        super(mensaje);
    }
}
