
package Gestion_de_inventarios;


public interface Calculadora {
    int ejecutar(int x, int y);
    
}
