
package UI;


import javax.swing.*;
import java.awt.*;

public class InitFrame extends JFrame {

    public InitFrame() {

        setTitle("SmartTask");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(25,25,25));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50,50,50,50));

        JLabel title = new JLabel("SmartTask PRO");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));

        JLabel description = new JLabel("<html><div style='text-align:center;'>"
                + "Organiza correctamente tus tareas para eficientar"
                + " tu productividad "
                + ""
                + "</div></html>");

        description.setAlignmentX(Component.CENTER_ALIGNMENT);
        description.setForeground(Color.LIGHT_GRAY);
        description.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        JButton start = new JButton("Start Managing");
        start.setAlignmentX(Component.CENTER_ALIGNMENT);
        start.setBackground(new Color(0,140,255));
        start.setForeground(Color.WHITE);
        start.setFocusPainted(false);
        start.setFont(new Font("Segoe UI", Font.BOLD, 16));
        start.setMaximumSize(new Dimension(200,50));

        start.addActionListener(e -> {
            new MainFrame().setVisible(true);
            dispose();
        });

        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0,20)));
        panel.add(description);
        panel.add(Box.createRigidArea(new Dimension(0,40)));
        panel.add(start);

        add(panel);
    }
}
