
package UI; 

import model.Task;
import service.TaskManager;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {

    private TaskManager manager;
    private JPanel taskPanel;
    private JLabel statsLabel;
    private JTextField searchField;
    private JComboBox<String> filterBox;

    private boolean darkMode = true;

    private Color BACKGROUND = new Color(25,25,25);
    private Color CARD_COLOR = new Color(40,40,40);
    private Color TEXT_COLOR = new Color(230,230,230);

    public MainFrame() {

        manager = new TaskManager();

        setTitle("SmartTask Dashboard");
        setSize(1200,700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        initUI();
        loadTasks();
    }

    private void initUI(){

        setLayout(new BorderLayout());
        getContentPane().setBackground(BACKGROUND);

        add(createTopBar(), BorderLayout.NORTH);

        taskPanel = new JPanel();
        taskPanel.setLayout(new BoxLayout(taskPanel, BoxLayout.Y_AXIS));
        taskPanel.setBackground(BACKGROUND);

        JScrollPane scroll = new JScrollPane(taskPanel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BACKGROUND);

        add(scroll, BorderLayout.CENTER);
    }

    private JPanel createTopBar(){

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(BACKGROUND);
        top.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        JButton newTask = new JButton("New Task");
        newTask.addActionListener(e -> addTask());

        JButton toggleTheme = new JButton("Toggle Theme");
        toggleTheme.addActionListener(e -> toggleTheme());

        searchField = new JTextField(15);
        searchField.addActionListener(e -> loadTasks());

        filterBox = new JComboBox<>(new String[]{"All","Completed","Pending"});
        filterBox.addActionListener(e -> loadTasks());

        statsLabel = new JLabel();
        statsLabel.setForeground(TEXT_COLOR);

        JPanel left = new JPanel();
        left.setBackground(BACKGROUND);
        left.add(newTask);
        left.add(toggleTheme);

        JPanel center = new JPanel();
        center.setBackground(BACKGROUND);
        center.add(new JLabel("Search:"));
        center.add(searchField);
        center.add(filterBox);

        top.add(left, BorderLayout.WEST);
        top.add(center, BorderLayout.CENTER);
        top.add(statsLabel, BorderLayout.EAST);

        return top;
    }

    private void loadTasks(){

        taskPanel.removeAll();

        List<Task> tasks = manager.getTasksSortedByPriority();

        String search = searchField.getText().toLowerCase();
        String filter = (String) filterBox.getSelectedItem();

        tasks = tasks.stream()
                .filter(t -> t.getTitle().toLowerCase().contains(search))
                .filter(t -> {
                    if(filter.equals("Completed")) return t.isCompleted();
                    if(filter.equals("Pending")) return !t.isCompleted();
                    return true;
                })
                .collect(Collectors.toList());

        for(Task t : tasks){
            taskPanel.add(createCard(t));
            taskPanel.add(Box.createRigidArea(new Dimension(0,10)));
        }

        updateStats();

        taskPanel.revalidate();
        taskPanel.repaint();
    }

    private JPanel createCard(Task task){

    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(CARD_COLOR);
    card.setBorder(BorderFactory.createEmptyBorder(15,20,15,20));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE,180));

    JLabel title = new JLabel(task.getTitle());
    title.setForeground(TEXT_COLOR);
    title.setFont(new Font("Segoe UI", Font.BOLD,18));

    if(task.isCompleted()){
        title.setText("✔ " + task.getTitle());
    }

    JLabel description = new JLabel("<html><i>" + task.getDescription() + "</i></html>");
    description.setForeground(Color.LIGHT_GRAY);

    JLabel info = new JLabel("Due: " + task.getDueDate() +
            " | Priority Score: " + task.calculatePriority());
    info.setForeground(Color.GRAY);

    JButton complete = new JButton("Complete");
    complete.addActionListener(e -> {
        task.setCompleted(true);
        manager.saveTasks();
        loadTasks();
    });

    JButton edit = new JButton("Edit");
    edit.addActionListener(e -> editTask(task));

    JButton delete = new JButton("Delete");
    delete.addActionListener(e -> {
        manager.removeTask(task);
        manager.saveTasks();
        loadTasks();
    });

    JPanel buttons = new JPanel();
    buttons.setBackground(CARD_COLOR);
    buttons.add(complete);
    buttons.add(edit);
    buttons.add(delete);

    JPanel text = new JPanel();
    text.setBackground(CARD_COLOR);
    text.setLayout(new BoxLayout(text,BoxLayout.Y_AXIS));
    text.add(title);
    text.add(Box.createRigidArea(new Dimension(0,5)));
    text.add(description);
    text.add(Box.createRigidArea(new Dimension(0,5)));
    text.add(info);

    card.add(text, BorderLayout.CENTER);
    card.add(buttons, BorderLayout.EAST);

    return card;
}

    private void updateStats(){

        int total = manager.getTasks().size();
        long completed = manager.getTasks().stream().filter(Task::isCompleted).count();
        long pending = total - completed;

        statsLabel.setText("Total: " + total +
                " | Completed: " + completed +
                " | Pending: " + pending);
    }

    private void toggleTheme(){

        darkMode = !darkMode;

        if(darkMode){
            BACKGROUND = new Color(25,25,25);
            CARD_COLOR = new Color(40,40,40);
            TEXT_COLOR = new Color(230,230,230);
        } else {
            BACKGROUND = Color.WHITE;
            CARD_COLOR = new Color(230,230,230);
            TEXT_COLOR = Color.BLACK;
        }

        getContentPane().setBackground(BACKGROUND);
        loadTasks();
    }

 private void addTask() {

    JPanel panel = new JPanel(new GridLayout(4,2,10,10));

    JTextField titleField = new JTextField();

    JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
    dateSpinner.setEditor(dateEditor);

    JSpinner difficultySpinner = new JSpinner(new SpinnerNumberModel(1,1,5,1));
    JSpinner hoursSpinner = new JSpinner(new SpinnerNumberModel(1,1,100,1));

    panel.add(new JLabel("Title:"));
    panel.add(titleField);

    panel.add(new JLabel("Due Date:"));
    panel.add(dateSpinner);

    panel.add(new JLabel("Difficulty (1-5):"));
    panel.add(difficultySpinner);

    panel.add(new JLabel("Estimated Hours:"));
    panel.add(hoursSpinner);

    int result = JOptionPane.showConfirmDialog(
            this,
            panel,
            "New Task",
            JOptionPane.OK_CANCEL_OPTION
    );

    if(result == JOptionPane.OK_OPTION){

        String title = titleField.getText().trim();
        if(title.isEmpty()){
            JOptionPane.showMessageDialog(this,"Title cannot be empty");
            return;
        }

        java.util.Date selectedDate = (java.util.Date) dateSpinner.getValue();
        LocalDate dueDate = selectedDate.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();

        int difficulty = (int) difficultySpinner.getValue();
        int hours = (int) hoursSpinner.getValue();

        Task task = new Task(
                title,
                "",
                dueDate,
                difficulty,
                hours
        );

        manager.addTask(task);
        manager.saveTasks();
        loadTasks();
      }
    
    } 
    private void editTask(Task task) {

    JFrame frame = new JFrame("Edit Task");
    frame.setSize(450, 400);
    frame.setLocationRelativeTo(this);
    frame.setLayout(new GridLayout(6,2,10,10));
    frame.getContentPane().setBackground(BACKGROUND);

    JTextField titleField = new JTextField(task.getTitle());
    JTextArea descriptionArea = new JTextArea(task.getDescription());
    JScrollPane descScroll = new JScrollPane(descriptionArea);

    JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
    dateSpinner.setEditor(dateEditor);
    dateSpinner.setValue(java.sql.Date.valueOf(task.getDueDate()));

    JSpinner difficultySpinner = new JSpinner(new SpinnerNumberModel(task.getDifficulty(),1,5,1));
    JSpinner hoursSpinner = new JSpinner(new SpinnerNumberModel(task.getEstimatedHours(),1,100,1));

    JButton saveButton = new JButton("Save Changes");

    frame.add(new JLabel("Title:"));
    frame.add(titleField);

    frame.add(new JLabel("Description:"));
    frame.add(descScroll);

    frame.add(new JLabel("Due Date:"));
    frame.add(dateSpinner);

    frame.add(new JLabel("Difficulty (1-5):"));
    frame.add(difficultySpinner);

    frame.add(new JLabel("Estimated Hours:"));
    frame.add(hoursSpinner);

    frame.add(new JLabel(""));
    frame.add(saveButton);

    saveButton.addActionListener(e -> {

        String title = titleField.getText().trim();
        String description = descriptionArea.getText().trim();

        if(title.isEmpty() || description.isEmpty()){
            JOptionPane.showMessageDialog(frame,"All fields are required");
            return;
        }

        java.util.Date selectedDate = (java.util.Date) dateSpinner.getValue();
        LocalDate dueDate = selectedDate.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();

        int difficulty = (int) difficultySpinner.getValue();
        int hours = (int) hoursSpinner.getValue();

        task.setTitle(title);
        task.setDescription(description);
        task.setDueDate(dueDate);
        task.setDifficulty(difficulty);
        task.setEstimatedHours(hours);

        manager.saveTasks();
        loadTasks();

        frame.dispose();
    });

    frame.setVisible(true);
}
}