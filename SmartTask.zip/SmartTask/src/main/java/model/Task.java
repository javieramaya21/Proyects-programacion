
package model;

//Librerias a utilizar
import java.time.LocalDate; //libreria de fecha local para uso de fecha hora y dia
import java.time.temporal.ChronoUnit;

public class Task {
    
    private String title;
    private String description;
    private LocalDate dueDate;
    private int difficulty; //1-5
    private int estimatedHours;
    private boolean completed;    
    
    //constructores
    public Task(String title, String description, LocalDate dueDate,
            int difficulty, int estimatedHours){
    
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.difficulty = difficulty;
        this.estimatedHours = estimatedHours;
        this.completed = false;
                
    }
    
    // Setters y getters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public int getEstimatedHours() {
        return estimatedHours;
    }

    public void setEstimatedHours(int estimatedHours) {
        this.estimatedHours = estimatedHours;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
    
    
    
    //metodo o funcion para calcular prioridad
    
    public int calculatePriority(){
        
        long daysRemaining = ChronoUnit.DAYS.between(LocalDate.now(), dueDate);
        
        return (int)((daysRemaining * -2) + (difficulty * 3) + estimatedHours);  
        
    }
    
    @Override
    public String toString(){
        return "Task: " + title +
                "\n Description: " + description +
                "\n DueDate: " + dueDate +
                "\n Difficulty: " + difficulty +
                "\n Estimated Hours: " + estimatedHours +
                "\n Completed: " + completed +
                "\nPriority Score: " + calculatePriority();
        
    }
    
    
}

