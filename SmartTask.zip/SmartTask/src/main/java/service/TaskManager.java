package service;

import model.Task;
import util.FileManager;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TaskManager {

    private List<Task> tasks;

    public List<Task> getTasks() {
    return tasks;
    }
    
    public void removeTask(Task task) {
    tasks.remove(task);
    }
    
    public TaskManager() {
        // Cargar tareas automáticamente desde archivo
        tasks = FileManager.loadTasks();
    }

    // Agregar tarea
    public void addTask(Task task) {
        tasks.add(task);
    }

    // Eliminar tarea por índice
    public void removeTask(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
        } else {
            System.out.println("Índice inválido.");
        }
    }

    // Marcar tarea como completada
    public void markTaskCompleted(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks.get(index).setCompleted(true);
        } else {
            System.out.println("Índice inválido.");
        }
    }

    // Obtener tareas ordenadas por prioridad dinámica
    public List<Task> getTasksSortedByPriority() {
        List<Task> sortedTasks = new ArrayList<>(tasks);

        sortedTasks.sort(
                Comparator.comparing(Task::calculatePriority).reversed()
        );

        return sortedTasks;
    }

    // Obtener todas las tareas
    public List<Task> getAllTasks() {
        return tasks;
    }

    // Guardar tareas en archivo
    public void saveTasks() {
        FileManager.saveTasks(tasks);
    }

    // Estadísticas básicas
    public int getTotalTasks() {
        return tasks.size();
    }

    public long getCompletedTasksCount() {
        return tasks.stream()
                .filter(Task::isCompleted)
                .count();
    }
}
