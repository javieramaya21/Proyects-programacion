package App;


import UI.InitFrame;

public class Main {
    public static void main(String[] args) {
        new InitFrame().setVisible(true);
    }
}
