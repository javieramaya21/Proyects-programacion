
package util;

import model.Task;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

    private static final String FILE_NAME = "task.txt";
    
    //Agregar tareas
    public static void saveTasks(List<Task> tasks){
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))){
        
            for(Task task : tasks){
                writer.write(task.getTitle() + ";" +
                        task.getDueDate() + ";" + 
                        task.getDifficulty() + ";" + 
                        task.getEstimatedHours() + ";" + 
                        task.isCompleted());
                writer.newLine();
            }
        } catch(IOException e){
            System.out.println("Error para guardar tarea:" + e.getMessage());
        }
    } 
        //visualizar las tareas
        public static List<Task> loadTasks() {
            
            List<Task> tasks = new ArrayList<>();
            
            File file = new File(FILE_NAME);

        if (!file.exists()) {
            return tasks;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] parts = line.split(";");

                String title = parts[0];
                LocalDate dueDate = LocalDate.parse(parts[1]);
                int difficulty = Integer.parseInt(parts[2]);
                int estimatedHours = Integer.parseInt(parts[3]);
                boolean completed = Boolean.parseBoolean(parts[4]);

                Task task = new Task(title, "", dueDate, difficulty, estimatedHours);
                task.setCompleted(completed);

                tasks.add(task);
            }

        } catch (IOException e) {
            System.out.println("Error al cargar tareas: " + e.getMessage());
        }

        return tasks;
        }
    }


